Citizen.CreateThread(function()
    while not Config do Wait(100) end
    Wait(500)
    SendNUIMessage({
        action = 'init',
        config = Config
    })
end)

function Alert(title, message, time, type)
	SendNUIMessage({
		action = 'open',
		title = title,
		type = type,
		message = message,
		time = time,
	})
end

RegisterNetEvent('m-Notify:Alert')
AddEventHandler('m-Notify:Alert', function(title, message, time, type)
	Alert(title, message, time, type)
end)


RegisterCommand('success', function()
	exports['m-Notify']:Alert("SUCCESS", "Notify, Dev By Matthew", 5000, 'success')
end)

RegisterCommand('info', function()
	exports['m-Notify']:Alert("INFO", "Notify, Dev By Matthew", 5000, 'info')
end)

RegisterCommand('error', function()
	exports['m-Notify']:Alert("ERROR", "Notify, Dev By Matthew", 5000, 'error')
end)

RegisterCommand('warning', function()
	exports['m-Notify']:Alert("WARNING", "Notify, Dev By Matthew", 5000, 'warning')
end)

RegisterCommand('phone', function()
	exports['m-Notify']:Alert("SMS", "Notify, Dev By Matthew", 5000, 'phonemessage')
end)

RegisterCommand('longtext', function()
	exports['m-Notify']:Alert("LONG MESSAGE", "Notify, Dev By Matthew", 5000, 'neutral')
end)
