To display a notification You can use:

# Client side

exports['m-Notify']:Alert("Title", "Message", Time, 'type')

# Server side

TriggerClientEvent('m-Notify:Alert', source, "Title", "Message", Time, 'type')


[Title] : "Title" or {text="Title", caption="Caption"}

[Time] : 1000 = 1 second | 5000 = 5 seconds

[Type]: Default Types:
    - success (green)
    - primary (blue)
    - warning (yellow)
    - error (red)
    - police (blue)
    - ambulance (red)
You can add more Types easily in Config.VariantDefinitions 


If you need help contact me on email : aensnassan@gmail.com