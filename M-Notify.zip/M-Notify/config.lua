Config = {}

Config.NotificationStyling = {
    group = true, -- Allow notifications to stack with a badge instead of repeating
    position = "top-right", -- top-left | top-right | bottom-left | bottom-right | top | bottom | left | right | center
    progress = true, -- Display Progress Bar In Notifications
    mode = "light" -- Notification Style (light | dark | colorful)
}

Config.VariantDefinitions = { 
    success = { 
        icon = 'fas fa-check', 
        color = "#47cf73",
        sound = "sound.wav",
        volume = 0.3,
    }, 
    primary = { 
        icon = 'fas fa-info', 
        color = "#1c75d2",
        sound = "sound.wav",
        volume = 0.3,
    }, 
    error = { 
        icon = 'fas fa-xmark', 
        color = "#dc3545",
        sound = "sound.wav",
        volume = 0.3,
    }, 
    warnning = { 
      icon = "fas fa-exclamation", 
      color = "#FFB300",
      sound = "sound.wav",
      volume = 0.3,
    }, 
    police = { 
        icon = 'fas fa-shield-halved', 
        color = "#0D54C8",
        sound = "sound.wav",
        volume = 0.3,
    }, 
    ambulance = { 
        icon = 'fas fa-ambulance', 
        color = "#f44236",
        sound = "sound.wav",
        volume = 0.3,
    } 
}
