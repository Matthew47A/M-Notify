$(function () {
    var Config = {
        NotificationStyling: {
            group: true,
            position: 'top-right',
            progress: true,
            mode: 'dark'
        },
        VariantDefinitions: {
            success: { icon: 'fas fa-check', color: "#47cf73" },
            primary: { icon: 'fas fa-info', color: "#1c75d2" },
            error: { icon: 'fas fa-xmark', color: "#dc3545" },
            warnning: { icon: "fas fa-exclamation", color: "#FFB300" },
            police: { icon: 'local_police', color: "#0D54C8" },
            ambulance: { icon: 'fas fa-ambulance', color: "#f44236" }
        }
    };

    var sound = new Audio('sound.wav');
    sound.volume = 0.5;

    function updatePosition() {
        var $container = $('.toast-container');
        var pos = Config.NotificationStyling.position;
        $container.removeClass('top-left top-right bottom-left bottom-right top bottom left right center');
        $container.addClass(pos);
    }

    function updateMode() {
        $('body').removeClass('mode-light mode-dark mode-colorful').addClass('mode-' + Config.NotificationStyling.mode);
    }

    updatePosition();
    updateMode();

    window.addEventListener('message', function (event) {
        if (event.data.action == 'init') {
            if (event.data.config) {
                if (event.data.config.NotificationStyling) {
                     Config.NotificationStyling = Object.assign(Config.NotificationStyling, event.data.config.NotificationStyling);
                }
                if (event.data.config.mode) {
                     Config.NotificationStyling = Object.assign(Config.NotificationStyling, event.data.config);
                }
                
                if (event.data.config.VariantDefinitions) {
                    Config.VariantDefinitions = event.data.config.VariantDefinitions;
                }

                updatePosition();
                updateMode();
            }
        } else if (event.data.action == 'open') {
            var number = Math.floor((Math.random() * 1000) + 1);
            var type = event.data.type || 'primary';
            var title = event.data.title;
            var message = event.data.message || '';
            var time = event.data.time || 5000;
            var seconds = Math.ceil(time / 1000);

            if (type === 'warning' && !Config.VariantDefinitions['warning'] && Config.VariantDefinitions['warnning']) {
                type = 'warnning';
            }
            if (!Config.VariantDefinitions[type]) {
                type = 'primary';
            }

            var variant = Config.VariantDefinitions[type];
            var icon = variant.icon;
            var color = variant.color;

            if (variant.sound) {
                var variantSound = new Audio(variant.sound);
                variantSound.volume = variant.volume || 0.5;
                variantSound.play().catch(e => {});
            }

            if (!title) {
                title = type.charAt(0).toUpperCase() + type.slice(1);
            }

            if (Config.NotificationStyling.group) {
                var $existing = $(`.notification-card[data-title="${title}"][data-message="${message}"]`).first();
                if ($existing.length > 0) {
                    var $progressCircle = $existing.find('.notification-spinner-progress');
                    
                    anime.remove($existing[0]);
                    if ($progressCircle.length) anime.remove($progressCircle[0]);

                    anime({
                        targets: $existing[0],
                        scale: [1, 1.05, 1],
                        duration: 300,
                        easing: 'easeInOutQuad'
                    });

                    var oldInterval = $existing.data('interval');
                    if (oldInterval) clearInterval(oldInterval);

                    startTimer($existing, time, null, $progressCircle);
                    return; 
                }
            }

            var progressHtml = Config.NotificationStyling.progress ? `
            <div class="notification-spinner-container">
                <svg class="notification-spinner" width="44" height="44" viewBox="0 0 44 44">
                    <circle class="notification-spinner-bg" cx="22" cy="22" r="18" fill="none" stroke-width="4"></circle>
                    <circle class="notification-spinner-progress" cx="22" cy="22" r="18" fill="none" stroke-width="4" stroke-dasharray="113" stroke-dashoffset="0" transform="rotate(-90 22 22)"></circle>
                </svg>
                <div class="notification-icon">
                    <i class="${icon}"></i>
                </div>
            </div>` : `
            <div class="notification-icon-box">
                <i class="${icon}"></i>
            </div>`;

            var html = `
            <div class="notification-card" id="notification-${number}" data-title="${title}" data-message="${message}" style="--variant-color: ${color}">
                ${progressHtml}
                <div class="notification-content">
                    <div class="notification-title">${title}</div>
                    <div class="notification-message">${message}</div>
                </div>
                <div class="notification-status-dot"></div>
            </div>`;

            var $container = $('.toast-container');
            $container.append(html);
            var $notification = $(`#notification-${number}`);
            var $progressCircle = $notification.find('.notification-spinner-progress');

            var startX = 50;
            if (Config.NotificationStyling.position.includes('left')) startX = -50;
            
            anime({
                targets: $notification[0],
                translateX: [startX, 0],
                opacity: [0, 1],
                easing: 'spring(1, 80, 10, 0)',
                duration: 800
            });

            startTimer($notification, time, null, $progressCircle);
        }
    });

    function startTimer($el, duration, $timerDisplay, $progressEl) {
        var remaining = duration;
        
        if ($progressEl && $progressEl.length) {
             $progressEl.css('stroke-dashoffset', '0');
             anime({
                targets: $progressEl[0],
                strokeDashoffset: [0, 113],
                easing: 'linear',
                duration: duration
            });
        }

        var interval = setInterval(function() {
            remaining -= 1000;
            if (remaining <= 0) {
                clearInterval(interval);
                closeNotification($el);
            }
        }, 1000);

        $el.data('interval', interval);
    }

    function closeNotification($el) {
        var interval = $el.data('interval');
        if (interval) clearInterval(interval);

        anime({
            targets: $el[0],
            opacity: 0,
            translateY: -20,
            easing: 'easeInQuad',
            duration: 400,
            complete: function() {
                $el.remove();
            }
        });
    }
});
