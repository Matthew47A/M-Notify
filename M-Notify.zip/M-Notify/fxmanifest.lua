fx_version 'adamant'

game 'gta5'

author 'Matthew Scripts' 
description 'Matthew Development Notification System'
version '1.0'

ui_page 'html/ui.html'

shared_script 'config.lua'

client_scripts {
	'client.lua',
}

files {
	'html/*.*'
}

export 'Alert'
